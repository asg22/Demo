'use strict'

var module = angular.module('Medpro', []);
module.controller("PatientInfoController",
		function($scope,$http) {

			$scope.patientInfoDto = {
				firstName:null,
				lastName:null
			};
			$scope.submit=function()	
			{	
				alert("inside");
				alert($scope.patientInfoDto.firstName);
				var data = angular.toJson($scope.patientInfoDto);
				$http.post("http://localhost:8096/medpro/patients/",data).
				then(function(response)
						{	//alert("hiihihi");
						
							$scope.details = response.data;
							//alert($scope.details[1]+" "+$scope.details[0]);
							//alert($scope.username+" "+$scope.password);
							$scope.flag=true;
						
							
						},function(response)
						{
							$scope.message = response.data.message;
						});
				}
					});