
var demoApp = angular.module('Medpro', [ 'ui.bootstrap', 'demo.controllers',
		'demo.services' ]);